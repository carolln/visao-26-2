import cv2
import sys
import numpy as np
import random
import matplotlib.pyplot as plt
import math

imgOriginal = cv2.imread(sys.argv[1], 0)
k = int(sys.argv[2])

img = cv2.imread('ruido' + str(k) + '.png', 0)

if k == 0:
    imgResultante = cv2.blur(img, (2, 2))
if k == 1:
    imgResultante = cv2.GaussianBlur(img, (3, 3), 0)
#etc

plt.subplot(1, 2, 1)
plt.imshow(img, cmap='gray')
plt.subplot(1, 2, 2)
plt.imshow(imgResultante, cmap='gray')
plt.title('PSNR = ' + str("%.2f" % cv2.PSNR(imgResultante, imgOriginal)))
plt.show()
